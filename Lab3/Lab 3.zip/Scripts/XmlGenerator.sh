#!/bin/bash

##################### Xml file generator #####################

echo "**************************************"
echo "This script creates the xml files needed by mcpat"

sleep 3

##################### Cache Line Size #####################

echo "**************************************"
echo "Specbzip || Spechmmer || Speclibm || Specmcf || Specsjeng"
echo "**************************************"
echo "Changing only the cache line size"

counter=16

while [ $counter -le 128 ]
do

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/cal_size_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/cal_size_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/cacheline_size_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/cal_size_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/cal_size_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/cacheline_size_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/cal_size_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/cal_size_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/cacheline_size_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/cal_size_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/cal_size_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/cacheline_size_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/cal_size_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/cal_size_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/cacheline_size_${counter}.xml

counter=$(($counter*2))

done

##################### L1 size #####################

echo "Changing only the l1i || l1d size"

counter=16

while [ $counter -le 128 ]
do

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/l1i_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/l1i_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/l1i_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/l1d_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/l1d_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/l1d_size_${counter}kB.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1i_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1i_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/l1i_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1d_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1d_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/l1d_size_${counter}kB.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/l1i_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/l1i_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/l1i_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/l1d_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/l1d_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/l1d_size_${counter}kB.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/l1i_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/l1i_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/l1i_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/l1d_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/l1d_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/l1d_size_${counter}kB.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1i_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1i_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/l1i_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1d_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1d_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/l1d_size_${counter}kB.xml

counter=$(($counter*2))

done

##################### L2 size #####################

echo "Changing only the l2 size"

counter=512

while [ $counter -le 4096 ]
do

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/l2_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/l2_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/l2_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/l2_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/l2_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/l2_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/l2_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/l2_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/l2_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/l2_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/l2_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/l2_size_${counter}kB.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/l2_size_${counter}kB/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/l2_size_${counter}kB/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/l2_size_${counter}kB.xml

counter=$(($counter*2))

done


##################### L1 I assoc || L1 D assoc || L2 assoc #####################

echo "Changing only the assocs"

counter=2

while [ $counter -le 8 ]
do

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/l1i_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/l1i_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/l1i_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/l1d_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/l1d_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/l1d_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specbzip/l2_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specbzip/l2_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specbzip/l2_assoc_${counter}.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1i_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1i_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/l1i_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1d_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/l1d_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/l1d_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/spechmmer/l2_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/spechmmer/l2_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/spechmmer/l2_assoc_${counter}.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/l1i_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/l1i_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/l1i_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/l1d_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/l1d_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/l1d_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/speclibm/l2_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/speclibm/l2_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/speclibm/l2_assoc_${counter}.xml



~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/l1i_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/l1i_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/l1i_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/l1d_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/l1d_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/l1d_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specmcf/l2_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specmcf/l2_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specmcf/l2_assoc_${counter}.xml




~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1i_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1i_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/l1i_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1d_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/l1d_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/l1d_assoc_${counter}.xml

~/my_mcpat/Scripts/GEM5ToMcPAT.py ~/my_gem5/spec_results/Lab_2.2/specsjeng/l2_assoc_${counter}/stats.txt ~/my_gem5/spec_results/Lab_2.2/specsjeng/l2_assoc_${counter}/config.json ~/my_mcpat/mcpat/ProcessorDescriptionFiles/inorder_arm.xml -o ~/my_mcpat/All_Xml_Files/specsjeng/l2_assoc_${counter}.xml

counter=$(($counter*2))

done


##################### End #####################

