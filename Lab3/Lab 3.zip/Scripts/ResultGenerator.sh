#!/bin/bash

##################### Xml file generator #####################

echo "**************************************"
echo "This script creates the txt files of the mcpat simulations using the xml files previously created"

sleep 3

##################### Cache Line Size #####################

echo "**************************************"
echo "Specbzip || Spechmmer || Speclibm || Specmcf || Specsjeng"
echo "**************************************"
echo "Changing only the cache line size"

counter=16

while [ $counter -le 128 ]
do

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/cacheline_size_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specbzip/cacheline_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/cacheline_size_${counter}.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/cacheline_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/cacheline_size_${counter}.xml -print_level 5 > ~/my_mcpat/Results/speclibm/cacheline_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/cacheline_size_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specmcf/cacheline_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/cacheline_size_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/cacheline_size_${counter}.txt


counter=$(($counter*2))

done

##################### L1 size #####################

echo "Changing only the l1i || l1d size"

counter=16

while [ $counter -le 128 ]
do

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/l1i_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specbzip/l1i_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/l1d_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specbzip/l1d_size_${counter}kB.txt



~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/l1i_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/l1i_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/l1d_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/l1d_size_${counter}kB.txt



~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/l1i_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/speclibm/l1i_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/l1d_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/speclibm/l1d_size_${counter}kB.txt



~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/l1i_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specmcf/l1i_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/l1d_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specmcf/l1d_size_${counter}kB.txt


~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/l1i_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/l1i_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/l1d_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/l1d_size_${counter}kB.txt


counter=$(($counter*2))

done

##################### L2 size #####################

echo "Changing only the l2 size"

counter=512

while [ $counter -le 4096 ]
do

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/l2_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specbzip/l2_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/l2_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/l2_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/l2_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/speclibm/l2_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/l2_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specmcf/l2_size_${counter}kB.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/l2_size_${counter}kB.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/l2_size_${counter}kB.txt

counter=$(($counter*2))

done


##################### L1 I assoc || L1 D assoc || L2 assoc #####################

echo "Changing only the assocs"

counter=2

while [ $counter -le 8 ]
do


~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/l1i_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specbzip/l1i_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/l1d_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specbzip/l1d_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specbzip/l2_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specbzip/l2_size_${counter}.txt



~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/l1i_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/l1i_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/l1d_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/l1d_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/spechmmer/l2_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/spechmmer/l2_size_${counter}.txt



~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/l1i_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/speclibm/l1i_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/l1d_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/speclibm/l1d_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/speclibm/l2_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/speclibm/l2_size_${counter}.txt



~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/l1i_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specmcf/l1i_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/l1d_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specmcf/l1d_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specmcf/l2_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specmcf/l2_size_${counter}.txt




~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/l1i_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/l1i_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/l1d_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/l1d_size_${counter}.txt

~/my_mcpat/mcpat/mcpat -infile ~/my_mcpat/All_Xml_Files/specsjeng/l2_assoc_${counter}.xml -print_level 5 > ~/my_mcpat/Results/specsjeng/l2_size_${counter}.txt


counter=$(($counter*2))

done


##################### End #####################

