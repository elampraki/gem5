#!/bin/bash

##################### specbzip #####################

echo "*******************sjeng specs*******************"
echo "This script tests how each parameter influences cpi"

sleep 3

##################### L1 D size || L1 I size || Cacheline size #####################

counter=16

while [ $counter -le 128 ]
do

./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/l1d_size_${counter}kB configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=${counter}kB  --l1i_size=32kB --l2_size=2MB --l1i_assoc=2 --l1d_assoc=2 --l2_assoc=8 --cacheline_size=64 --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000


./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/l1i_size_${counter}kB configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=64kB  --l1i_size=${counter}kB --l2_size=2MB --l1i_assoc=2 --l1d_assoc=2 --l2_assoc=8 --cacheline_size=64 --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/cal_size_${counter} configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=64kB  --l1i_size=32kB --l2_size=2MB --l1i_assoc=2 --l1d_assoc=2 --l2_assoc=8 --cacheline_size=${counter} --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

counter=$(($counter*2))

done



echo "Taking a break."
sleep 30



##################### L2 size #####################

counter=512

while [ $counter -le 4096 ]
do

./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/l2_size_${counter}kB configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=64kB --l1i_size=32kB --l2_size=${counter}kB --l1i_assoc=2 --l1d_assoc=2 --l2_assoc=8 --cacheline_size=64 --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

counter=$(($counter*2))

done



echo "Taking a break."
sleep 30


##################### Associativities #####################

counter=2

while [ $counter -le 8 ]
do

./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/l1i_assoc_${counter} configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=64kB --l1i_size=32kB --l2_size=2MB --l1i_assoc=${counter} --l1d_assoc=2 --l2_assoc=8 --cacheline_size=64 --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/l1d_assoc_${counter} configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=64kB --l1i_size=32kB --l2_size=2MB --l1i_assoc=2 --l1d_assoc=${counter} --l2_assoc=8 --cacheline_size=64 --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

./build/ARM/gem5.opt -d spec_results/Lab_2.2/specsjeng/l2_assoc_${counter} configs/example/se.py --cpu-type=MinorCPU --caches --l2cache --l1d_size=64kB --l1i_size=32kB --l2_size=2MB --l1i_assoc=2 --l1d_assoc=2 --l2_assoc=${counter} --cacheline_size=64 --cpu-clock=2GHz -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

counter=$(($counter*2))

done



echo "Taking a break."
sleep 30


##################### End #####################

